
int __thiscall FUN_0050ad60(void *this,void *param_1)

{
  int iVar1;
  
  iVar1 = 1;
  if (*(int *)((int)this + 0x5c) < *(int *)((int)this + 100)) {
    iVar1 = FUN_00509dc0(this,*(int *)((int)this + 0x5c),param_1);
  }
  return iVar1;
}

