
void __thiscall FUN_0050bb70(void *this,void *param_1)

{
  void *this_00;
  int iVar1;
  
  this_00 = (void *)FUN_00509670(this,0);
  if (this_00 != (void *)0x0) {
    iVar1 = FUN_00528040(this_00,0);
    FUN_0050a820(this,(uint)(iVar1 != 0),param_1);
  }
  return;
}

