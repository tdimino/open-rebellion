
undefined4 __fastcall FUN_0053b870(int param_1)

{
  return *(undefined4 *)(param_1 + 0x4c);
}

