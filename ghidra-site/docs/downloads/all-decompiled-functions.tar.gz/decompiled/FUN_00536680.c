
int __thiscall FUN_00536680(void *this,undefined4 param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  undefined3 extraout_var;
  
  bVar1 = FUN_0053a010((int)this);
  if (CONCAT31(extraout_var,bVar1) != 0) {
    FUN_004f8980(this,s__RoleBaseShipyardRDNotif__006aa820,s_BaseShipyardRD_006aa83c,param_2,param_1
                 ,(char *)0x0,param_3);
  }
  return CONCAT31(extraout_var,bVar1);
}

