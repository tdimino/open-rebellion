
int __thiscall FUN_0050f390(void *this,void *param_1)

{
  bool bVar1;
  undefined3 extraout_var;
  int iVar2;
  int iVar3;
  undefined4 local_4;
  
  bVar1 = FUN_0053a010((int)this);
  local_4 = CONCAT31(extraout_var,bVar1);
  if (local_4 != 0) {
    iVar2 = FUN_00539fd0(this,0);
    iVar3 = FUN_005404d0(this,*(uint *)((int)param_1 + 8));
    if (iVar3 != 0) {
      iVar3 = *(int *)((int)this + 0x58);
      if (iVar3 != *(int *)(iVar2 + 0x58)) {
        *(int *)((int)this + 0x58) = *(int *)(iVar2 + 0x58);
        iVar2 = FUN_004fd3d0();
        if (iVar2 != 0) {
          iVar2 = FUN_004fd600(param_1,*(uint *)((int)this + 0x24) >> 4 & 3);
          if (iVar2 != 0) {
                    /* WARNING: Load size is inaccurate */
            local_4 = (**(code **)(*this + 0x25c))(iVar3,*(undefined4 *)((int)this + 0x58),param_1);
          }
        }
      }
    }
  }
  return local_4;
}

